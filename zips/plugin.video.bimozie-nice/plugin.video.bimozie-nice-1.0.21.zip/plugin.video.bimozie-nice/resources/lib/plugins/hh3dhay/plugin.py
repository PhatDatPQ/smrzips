import re

from hh3dhay.parser.category import Parser as Category
from hh3dhay.parser.channel import Parser as Channel
from hh3dhay.parser.movie import Parser as Movie
from utils import csc_request as NICE
from utils.mozie_request import Request


class hh3dhay:
    domain = "https://hh3dhay.com"

    def getCategory(self):
        # response = Request().get(self.domain)
        response = NICE.execute({'method': 'GET','url': self.domain,'timeout': 10,})
        return Category().get(response.text), Channel().getTop(response.text)

    def getChannel(self, channel, page=1):
        if page > 1:
            url = f'{channel}/page/{page}'
        else:
            url = channel
        response = Request().get(url)
        return Channel().get(response, page)

    def getMovie(self, id):
        url = '%s' % (id)
        url = Movie().get_movie_link(Request().get(url))
        response = Request().get(url)
        return Movie().get(response)

    def getLink(self, movie):
        url = '%s' % (movie['link'])
        response = Request().get(url)
        return Movie().get_link(response, self.domain, url)

    def search(self, text):
        url = "%s/search/%s" % (self.domain, text)
        response = Request().get(url)
        return Channel().search_result(response)
