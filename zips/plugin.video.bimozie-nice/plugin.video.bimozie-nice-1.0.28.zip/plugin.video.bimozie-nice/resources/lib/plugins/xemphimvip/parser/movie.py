# -*- coding: utf-8 -*-
import json
import re

from bs4 import BeautifulSoup
from kodi_six.utils import py2_encode
from six.moves.urllib.parse import unquote


def from_char_code(*args):
    return ''.join(map(chr, args))


class Parser:
    key = "PhimMoi.Net@"
    def get_movie_link(self, response):
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        soup = BeautifulSoup(response, "html.parser")
        NICE = soup.find('script', type='application/json')
        DTALL = json.loads(re.search(r"(\{.*?\})\<",str(NICE)).group(1))
        OK = DTALL['props']['apolloState']
        try:
            LISTSS = json.loads(re.search(r'nodes.*?(\[.*?\])', str(NICE)).group(1))
            for SS in LISTSS:
                OKEP = OK[SS['id']]
                PHAN = OKEP['number']
                TAP = OKEP['children']
                server_name = f'PHẦN {PHAN}'
                if server_name not in movie['group']: movie['group'][server_name] = []
                for EP in TAP:
                    OKEPS = OK[EP['id']]
                    movie['group'][server_name].append({
                        'link': py2_encode(OKEPS['id']),
                        'title': '%s' % py2_encode('TẬP '+OKEPS['number'])
                    })
        except:
            server_name = 'XEMPHIM.VIP'
            if server_name not in movie['group']: movie['group'][server_name] = []
            movie['group'][server_name].append({
                'link': py2_encode(DTALL['props']['pageProps']['id']),
                'title': '%s' % py2_encode('FULL')
            })   
        return movie

    def get(self, request, domain, id, api, skipEps=False):
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        originURL = f'https://xemphim.vip/watch/{id}'
        # ID = int(re.findall("\d+", id)[0])
        ## GET SOURCE ##
        params = {
        "operationName":"TitleWatch",
        "variables":{
            "id":f"{id}",
            "server":"1"
        },
        "query":"query TitleWatch($id: String!, $server: String) {\n  title(id: $id, server: $server) {\n    id\n    nameEn\n    nameVi\n    intro\n    publishDate\n    tmdbPoster\n    tmdbBackdrop\n    srcUrl\n    srcServer\n    canUseVpn\n    vpnFee\n    spriteUrl\n    useVipLink\n    reachedWatchLimit\n    needImproveSubtitle\n    needImproveVideo\n    dmcaRemoved\n    type\n    number\n    subsceneSlug\n    movieInfo {\n      width\n      height\n      __typename\n    }\n    parent {\n      id\n      number\n      intro\n      publishDate\n      tmdbPoster\n      parent {\n        id\n        nameEn\n        nameVi\n        tmdbBackdrop\n        __typename\n      }\n      __typename\n    }\n    children {\n      id\n      number\n      __typename\n    }\n    relatedTitles {\n      ...TitleBasics\n      __typename\n    }\n    __typename\n  }\n}\n\nfragment TitleBasics on Title {\n  id\n  nameEn\n  nameVi\n  type\n  postedAt\n  tmdbPoster\n  publishDate\n  intro\n  imdbRating\n  countries\n  genres {\n    nameVi\n    slug\n    __typename\n  }\n  translation\n  __typename\n}\n"
        }
        rSS = request.post(api, json=params)
        rEP = json.loads(rSS)
        source = rEP['data']['title']['srcUrl']

        ## GET SUB ###
        jsub = {
        "operationName":"Subtitles",
        "variables":{
            "titleId":f"{id}"
        },
        "query":"query Subtitles($titleId: String!) {\n  subtitles(titleId: $titleId) {\n    id\n    subsceneId\n    language\n    releaseNames\n    files\n    comment\n    isDefault\n    acted\n    likes\n    dislikes\n    owner {\n      id\n      name\n      __typename\n    }\n    __typename\n  }\n}\n"
        }
        rSSub = request.post(api, json=jsub)
        rSub = json.loads(rSSub)
        # print(rSub)
        movie['links'].append({
            'link': source,
            'title': py2_encode(source),
            'type': 'Unknow',
            'originUrl': originURL,
            'resolve': False
        })
        return movie

    def get_link(self, response, originURL):
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        sources = re.search("var sources = (\[{.*}\]);", response) \
                  or re.search("var sources[\s]?=[\s]?(\[{.*}\]);var", response)
        if sources is not None:
            print(12313)
            return movie
            sources = json.loads(sources.group(1))
            for source in sources:
                url = unquote(re.search('\?url=(.*)', source['file']).group(1))
                movie['links'].append({
                    'link': url,
                    'title': 'Link %s' % py2_encode(source['label']),
                    'type': py2_encode(source['label']),
                    'originUrl': originURL,
                    'resolve': False
                })
        m = re.search('<iframe.*src="(.*?)"', response)
        if m is not None:
            source = unquote(m.group(1)).replace('\\', '')
            if source:
                if 'embedss.php?link=' in source:
                    source = re.search(r'embedss.php\?link=(.*)', source).group(1)
                if 'embedsp.php?link=' in source:
                    source = re.search(r'embedsp.php\?link=(.*)', source).group(1)

                movie['links'].append({
                    'link': source,
                    'title': py2_encode(source),
                    'type': 'Unknow',
                    'originUrl': originURL,
                    'resolve': False
                })

        return movie

