from six.moves.urllib.parse import quote_plus
from xemphimvip.parser.category import Parser as Category
from xemphimvip.parser.channel import Parser as Channel
from xemphimvip.parser.movie import Parser as Movie
from utils.mozie_request import Request
import re

class XemPhimVip:
    domain = 'https://xemphim.vip'
    api = 'https://xemphim.vip/b/g'
    cookie = {}
    h = {
        'Referer': domain,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36'
    }

    def __init__(self):
        self.request = Request(self.h, session=True)
    def getCategory(self):
        response = self.request.get(self.domain, cookies=self.cookie)
        return Category().get(response), Channel().get(response, 1)

    def getChannel(self, channel, page=1):
        if page > 1:
            url = '%s%s?page=%d' % (self.domain, channel, page)
        else:
            url = '%s%s' % (self.domain, channel)
        response = self.request.get(url, cookies=self.cookie)
        return Channel().get(response, page)

    def getMovie(self, id):
        return Movie().get_movie_link(self.request.get('%s%s'% (self.domain, id), cookies=self.cookie))

        # url = Movie().get_movie_link(
        #     self.request.get('%s%s'% (self.domain, id), cookies=self.cookie)
        # )
        # response = self.request.get('%s%s'% (self.domain, url), cookies=self.cookie)
        # return Movie().get(self.request ,self.domain, id , self.cookie)

    def getLink(self, movie):
        print(movie)
        # response = self.request.get(movie['link'], cookies=self.cookie)
        return Movie().get(self.request, self.domain, movie['link'], self.api)
        # return Movie().get_link(response, movie['link'])

    def search(self, text):
        url = "%s/search/%s" % (self.domain, quote_plus(text))
        response = self.request.get(url, cookies=self.cookie)
        return Channel().get(response, 1)
