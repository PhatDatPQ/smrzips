#!/usr/bin/env python
# -*- coding: utf-8 -*-
import re

from bs4 import BeautifulSoup
from kodi_six.utils import py2_encode
import utils.xbmc_helper as helper


class Parser:
    def get(self, response, page):

        channel = {
            'page': page,
            'page_patten': None,
            'movies': []
        }

        soup = BeautifulSoup(response, "html.parser")
        # get total page
        pages = soup.select_one('ul.pagination-list')
        m = re.findall(r'page?[/|=](\d+)/?', str(pages))
        if m:
            channel['page'] = max([int(x) for x in m])

        movies = soup.select('div.grid > div')
        if len(movies) > 0:
            for movie in movies:
                title = movie.select_one('h3.name.vi > a').find(text=True, recursive=False).strip()
                type = ""
                realtitle = ""
                if movie.select_one('h3.name.en') is not None:
                    realtitle = movie.select_one('h3.name.en > a').text.strip()
                if realtitle is not None:
                    label = "%s - %s" % (title, realtitle)
                else:
                    label = "%s" % (type, title)

                thumb = movie.select_one('a img').get('src')
                thumbnailfull = re.search('w342', thumb)
                if thumbnailfull:
                    thumb = thumb.replace('w342','original')
                channel['movies'].append({
                    'id': movie.select_one('a').get('href'),
                    'label': py2_encode(label),
                    'intro': py2_encode(label),
                    'title': py2_encode(title),
                    'realtitle': py2_encode(realtitle),
                    'thumb': thumb,
                    'type': py2_encode(type),
                })
        return channel
