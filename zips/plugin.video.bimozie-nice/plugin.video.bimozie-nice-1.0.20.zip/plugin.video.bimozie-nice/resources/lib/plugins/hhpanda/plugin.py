import re

from hhpanda.parser.category import Parser as Category
from hhpanda.parser.channel import Parser as Channel
from hhpanda.parser.movie import Parser as Movie
from utils.mozie_request import Request
from six.moves.urllib.parse import quote_plus


class hhpanda:
    domain = "https://hhpanda.tv"

    def getCategory(self):
        response = Request().get(self.domain)
        return Category().get(response), Channel().getTop(response, self.domain)

    def getChannel(self, channel, page=1):
        if page > 1:
            url = f'{self.domain}{channel}?page={page}'
        else:
            url = f'{self.domain}{channel}'
        response = Request().get(url)
        return Channel().get(response, page, self.domain)

    def getMovie(self, id):
        url = '%s%s' % (self.domain,id)
        url = Movie().get_movie_link(Request().get(url))
        response = Request().get('%s%s' % (self.domain,url))
        return Movie().get(response,self.domain)

    def getLink(self, movie):
        url = '%s%s' % (self.domain, movie['link'])
        response = Request().get(url)
        return Movie().get_link(response, self.domain, url)

    def search(self, text):
        url = "%s/search?q=%s" % (self.domain, quote_plus(text))
        response = Request().get(url)
        return Channel().search_result(response, self.domain)