import json
import re

import xbmc
import xbmcgui
import xbmcplugin

from . import xbmc_helper as helper
from .media_helper import MediaHelper
from .. import app

plugin = app.plugin


class PlayerHandler:
    @staticmethod
    def play(query=None, movie_id=None, link_id=None):
        if not query:
            query = json.loads(plugin.args['query'][0])
        else:
            query = json.loads(query.get('query')[0])
        # play_item = xbmcgui.ListItem()

        if int(query.get('direct')) == 0:
            instance, module, class_name = app.load_plugin(query)
            movie_item = query.get('movie_item')
            thumb = helper.text_encode(movie_item.get('thumb'))
            title = helper.text_encode(movie_item.get('title'))
            realtitle = helper.text_encode(movie_item.get('realtitle'))

            movie = instance().getLink(query.get('item'))
            if not movie or 'links' not in movie or len(movie['links']) == 0:
                return
            else:
                blacklist = ['hydrax', 'maya.bbigbunny.ml', 'blob', 'short.icu']

                def filter_blacklist(m):
                    for i in blacklist:
                        if i in m['link']: return False
                    return True

                movie['links'] = list(filter(filter_blacklist, movie['links']))
                if len(movie['links']) > 1:
                    # sort all links
                    try:
                        movie['links'] = sorted(
                            movie['links'], key=lambda elem: re.search(r'(\d+)', elem['title'])
                                                             and int(re.search(r'(\d+)', elem['title']).group(1))
                                                             or 0,
                            reverse=True
                        )
                    except Exception as e:
                        helper.log(e)

                    listitems = []
                    appened_list = []
                    for i in movie['links']:
                        if not next((d for d in appened_list if i.get('link') == d.get('link')), False):
                            listitems.append("%s (%s)" % (i["title"], i["link"]))
                            appened_list.append(i)

                    index = xbmcgui.Dialog().select("CHỌN LINK STREAM", listitems)
                    if index == -1:
                        return False
                    else:
                        movie = appened_list[index]
                else:
                    movie = movie['links'][0]

                # play_item.setArt({'thumb': thumb})
                # play_item.setLabel(title)
                # play_item.setLabel2(realtitle)
                # play_item.setInfo(type='video', infoLabels={
                #     'title': title,
                #     'originaltitle': realtitle,
                #     'plot': movie_item.get('intro')
                # })
        else:
            movie = query.get('item')

        # Parse link
        helper.log(f'PlayerHandler {movie}')
        mediatype = MediaHelper.resolve_link(movie)
        helper.log(f'PlayerHandler {mediatype}')
        if not movie['link']: return
        play_item = xbmcgui.ListItem(path=(movie['link']))
        play_item.setPath(str(movie['link']))
        if movie.get('subtitle'):
            from utils.mozie_request import Request
            req = Request()
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1',
                'TE': 'Trailers',
            }
            subsout=[]
            subt = False
            wybornapisow = True
            napisy = helper.get_file_path('napisy')
            url = movie.get('subtitle')
            if url:
                response = req.get(url, headers=headers)
                response = json.loads(response)
                for subtitle in response:
                    subt = subtitle.get('src',None)
                    subt2 = subtitle.get('file',None)
                    subt = subt if subt else subt2
                    label = subtitle.get('label',None)
                    subsout.append({'label':label,'subt':subt})
            if wybornapisow and subsout:
                labels = [x.get('label') for x in subsout]
                sel = xbmcgui.Dialog().select('CHỌN NGÔN NGỮ PHỤ ĐỀ',labels)    
                if sel>-1:
                    subt=subsout[sel].get('subt')
                    if subsout[sel].get('label') == 'Polish':
                        subt = napisy if helper.transPolish(subt) else subt
                else:
                    subt = False
            if isinstance(movie['subtitle'], list):
                play_item.setSubtitles(movie['subtitle'])
            else:
                try:
                    play_item.setSubtitles([subt])
                except:
                    pass                
        xbmcplugin.setResolvedUrl(plugin.handle, True, listitem=play_item)

        # play_item.setProperty('IsPlayable', 'true')
        # play_item.setProperty('isFolder', 'false')

        # playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        # playlist.clear()
        # playlist.add(str(movie['link']), play_item)

        # player_type = xbmc.PLAYER_CORE_AUTO
        # player = xbmc.Player()
        # player.play(playlist)

        # player.play(str(movie['link']), listitem=play_item)
        # while not player.isPlaying():
        #     xbmc.sleep(100)

        # xbmcplugin.endOfDirectory(plugin.handle)
        # return True
