# -*- coding: utf-8 -*-

import re

from .. import xbmc_helper as helper
from ..mozie_request import Request
from utils.fmoviesto import FMTHelper
from utils import csc_request as NICE
# import requests

UA='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0'

headers = {
	'User-Agent': UA,
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
	'Connection': 'keep-alive',
	'Upgrade-Insecure-Requests': '1',
	'TE': 'Trailers',
}
req = Request()
# sess = requests.Session()

def get_link(url,media):
    helper.log("*********************** Apply Fmovies.To url %s" % url)
    pattern = r'(?://|\.)((?:my?|viz)cloud\.(?:to|digital|cloud))/(?:embed|e)/([0-9a-zA-Z]+)'
    hostm_id = re.findall(pattern,url,re.DOTALL)
    if hostm_id:
        media_id = hostm_id[0][1]
        host = hostm_id[0][0]
        med_id = FMTHelper.vidcloud_deco(media_id).replace('=','').replace('/','_')
        # print(med_id)
        link = re.sub('/(?:embed|e)/','/info/',url).replace(media_id,med_id.replace('=','').replace('/','_'))
        # print(link)
    stream_url = ''
    try:
        response = req.get(link, headers=headers, verify=False).json()
        # response1 = NICE.execute({'method': 'GET','url': link,'timeout': 10,})
        # print(response)
        # print(response1)
        outz=[]

        if 'success' in response:
            if response.get('success',None):
                srcs = response.get('media',None).get('sources',None)
                for src in srcs:
                    fil = src.get('file',None)
                    if 'm3u8' in fil:
                        stream_url = fil+'|User-Agent='+UA+'&Referer='+url
                        break
        elif 'status' in response:
            if response.get('status',None) == 200:
                srcs = response.get('data',None).get('media',None).get('sources',None)
                for src in srcs:
                    fil = src.get('file',None)
                    if 'm3u8' in fil:
                        stream_url = fil+'|User-Agent='+UA+'&Referer='+url
                        break
    except:
        pass

    # req = Request()

    # response = req.get(url, redirect=True)
    # url = re.search(r'"file": "(.*?)",', response).group(1)
    # url = "https://animehay.kyunkyun.net{}".format(url)

    return stream_url, 'FMOVIES.TO M-VIZ-CLOUD'
