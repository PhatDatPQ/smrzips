import sys, base64, os
from six.moves.urllib.parse import unquote


class FMTHelper:
    try:
        import string
        STANDARD_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
        CUSTOM_ALPHABET =   '5uLKesbh0nkrpPq9VwMC6+tQBdomjJ4HNl/fWOSiREvAYagT8yIG7zx2D13UZFXc' #23/05/22
        # CUSTOM_ALPHABET =   "51wJ0FDq/UVCefLopEcmK3ni4WIQztMjZdSYOsbHr9R2h7PvxBGAuglaN8+kXT6y"  #26/05/22
        ENCODE_TRANS = string.maketrans(STANDARD_ALPHABET, CUSTOM_ALPHABET)
        DECODE_TRANS = string.maketrans(CUSTOM_ALPHABET, STANDARD_ALPHABET)
    except:
        STANDARD_ALPHABET = b'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
        CUSTOM_ALPHABET =   b'5uLKesbh0nkrpPq9VwMC6+tQBdomjJ4HNl/fWOSiREvAYagT8yIG7zx2D13UZFXc' #23/05/22
        # CUSTOM_ALPHABET =   b"51wJ0FDq/UVCefLopEcmK3ni4WIQztMjZdSYOsbHr9R2h7PvxBGAuglaN8+kXT6y"  #26/05/22

        ENCODE_TRANS = bytes.maketrans(STANDARD_ALPHABET, CUSTOM_ALPHABET)
        DECODE_TRANS = bytes.maketrans(CUSTOM_ALPHABET, STANDARD_ALPHABET)
    def __init__(self):
        pass
    
    @staticmethod
    def encode2(input):
        return base64.b64encode(input).translate(FMTHelper.ENCODE_TRANS)
    @staticmethod
    def decode2(input):
        try:    
            xx= input.translate(FMTHelper.DECODE_TRANS)
        except:
            xx= str(input).translate(FMTHelper.DECODE_TRANS)
        return base64.b64decode(xx)
  
    def getVerid(id):
        ab='aaaaaa'
        ac = id
        hj = FMTHelper.dekodujNowe(ab,ac)
        if sys.version_info >= (3,0,0):
            hj=hj.encode('Latin_1')
        hj2 = FMTHelper.encode2(hj)   
        if sys.version_info >= (3,0,0):
            hj2=(hj2.decode('utf-8'))
        hjkl = ab + hj2
        return hjkl
    @staticmethod
    def dekodujNowe(t,n):
        #n = encode2(n)
        r=[]
        i=[]
        u=0
        x=''
        c = 256
        for o in range(c):
            i.append(o)
        o=0
        for o in range(c):
            #u = (u + i[o] + t.charCodeAt(o % t.length)) % c
            u = (u + i[o] + ord(t[o%len(t)]))%c
            r = i[o]
            i[o] = i[u]
            i[u] = r
        e = 0
        u = 0
        o =0
        for e in range(len(n)):
        #e+=1
            o = (o + e) % c
            u = (u + i[o]) % c
            r = i[o]
            i[o] = i[u]
            i[u] = r
        #x += String.fromCharCode(n.charCodeAt(e) ^ i[(i[o] + i[u]) % c])
            if sys.version_info >= (3,0,0):
                try:
                    x += chr((n[e])^ i[(i[o] + i[u]) % c] )
                except:
                    x += chr(ord(n[e])^ i[(i[o] + i[u]) % c] )
            else:
                x += chr(ord(n[e])^ i[(i[o] + i[u]) % c] )
        return x
    @staticmethod
    def dekoduj(r,o):
        t = []
        e = []
        n = 0
        a = ""
        for f in range(256): 
            e.append(f)

        for f in range(256):

            n = (n + e[f] + ord(r[f % len(r)])) % 256
            t = e[f]
            e[f] = e[n]
            e[n] = t

        f = 0
        n = 0
        for h in range(len(o)):
            f = f + 1
            n = (n + e[f % 256]) % 256
            if not f in e:
                f = 0
                t = e[f]
                e[f] = e[n]
                e[n] = t

                a += chr(ord(o[h]) ^ e[(e[f] + e[n]) % 256])
            else:
                t = e[f]
                e[f] = e[n]
                e[n] = t
                if sys.version_info >= (3,0,0):
                    a += chr((o[h]) ^ e[(e[f] + e[n]) % 256])
                else:
                    a += chr(ord(o[h]) ^ e[(e[f] + e[n]) % 256])
        return a
    @staticmethod
    def DecodeLink(mainurl):
        ab=mainurl[0:6]   #23.09.21
        ac2 = mainurl[6:]    #23.09.21
        ac= FMTHelper.decode2(ac2)
        link = FMTHelper.dekodujNowe(ab,ac)
        link = unquote(link)
        return link
    # @staticmethod
    # def dec(chra):
    #     try:    
    #         if sys.version_info >= (3,0,0):
    #             chra = repr(chra.encode('utf-8'))
    #             chra = chra.replace('\\xc3\\xaa','ę').replace('\\xc3\\x8a','Ę')
    #             chra = chra.replace('\\xc3\\xa6','ć').replace('\\xc3\\x86','Ć')
    #             chra = chra.replace('\\xc2\\xbf','ż').replace('\\xc2\\x9f','Ż')
    #             chra = chra.replace('\\xc2\\xb9','ą').replace('\\xc2\\x99','Ą')
    #             chra = chra.replace('\\xc5\\x93','ś').replace('\\xc5\\x92','Ś')
    #             chra = chra.replace('\\xc3\\xb3','ó').replace('\\xc3\\x93','Ó')
    #             chra = chra.replace('\\xc5\\xb8','ź').replace('\\xc5\\xb7','Ź')
    #             chra = chra.replace('\\xc2\\xb3','ł').replace('\\xc2\\x93','Ł')
    #             chra = chra.replace('\\xc3\\xb1','ń').replace('\\xc3\\x91','Ń')
    #             chra = chra .replace("b\'",'')
    #             chra = chra .replace("\\n",'\n').replace("\\r",'\r') 
    #             chra = chra .replace("\\'","'")
    #         else:
    #             chra = chra.replace('\xc3\xaa','ę').replace('\xc3\x8a','Ę')
    #             chra = chra.replace('\xc3\xa6','ć').replace('\xc3\x86','Ć')
    #             chra = chra.replace('\xc2\xbf','ż').replace('\xc2\x9f','Ż')
    #             chra = chra.replace('\xc2\xb9','ą').replace('\xc2\x99','Ą')
    #             chra = chra.replace('\xc5\x93','ś').replace('\xc5\x92','Ś')
    #             chra = chra.replace('\xc3\xb3','ó').replace('\xc3\x93','Ó')
    #             chra = chra.replace('\xc5\xb8','ź').replace('\xc5\xb7','Ź')
    #             chra = chra.replace('\xc2\xb3','ł').replace('\xc2\x93','Ł')
    #             chra = chra.replace('\xc3\xb1','ń').replace('\xc3\x91','Ń')
    #     except:
    #         pass
    #     return chra
    # @staticmethod
    # def transPolish(subtlink, request):
    #     import xbmc, xbmcvfs, xbmcaddon
    #     ADDON = xbmcaddon.Addon()
    #     ADDON_ID = ADDON.getAddonInfo('id')
    #     try:
    #         DATAPATH = xbmcvfs.translatePath(ADDON_ID.getAddonInfo('profile'))
    #     except:
    #         DATAPATH = xbmc.translatePath(ADDON_ID.getAddonInfo('profile')).decode('utf-8')

    #     ### SETTING PATCH SUB ###
    #     headers = {
    #         'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0',
    #         'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    #         'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
    #         'Connection': 'keep-alive',
    #         'Upgrade-Insecure-Requests': '1',
    #         'TE': 'Trailers',
    #     }
    #     napisy = os.path.join(DATAPATH,'napisy')
    #     try:
    #         response = request.get(subtlink, headers=headers, verify=False)#.content
    #         if sys.version_info >= (3,0,0):
    #             response  = response.text
    #         else:
    #             response  = response.content
    #         gg=FMTHelper.dec(response)
    #         open(napisy, 'w').write(gg)
    #         return True
    #     except:
    #         return False

