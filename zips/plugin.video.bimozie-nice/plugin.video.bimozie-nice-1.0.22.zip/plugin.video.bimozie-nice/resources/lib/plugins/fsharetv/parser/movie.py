# -*- coding: utf-8 -*-
import json
import re

from bs4 import BeautifulSoup
from kodi_six.utils import py2_encode
from six.moves.urllib.parse import unquote
from utils.mozie_request import Request


def from_char_code(*args):
    return ''.join(map(chr, args))


class Parser:
    def get_movie_link(self, response):
        soup = BeautifulSoup(response, "html.parser")
        return soup.select_one('a.btn-watch').get('href')

    def get(self, response, domain, skipEps=False):
        req = Request()
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        # print(response)
        soup = BeautifulSoup(response, "html.parser")
        subviet = soup.select_one("track").get('src')
        # id="trailer".*?value="([^"]+).*?Movie.setSource\('(.*?)',.*?Subtitle.init\('(.*?)'
        sources = re.findall("Movie.setSource\('(.*?)',.*?Subtitle.init\('(.*?)'",response, re.DOTALL)
        ID = re.search(r'id="trailer".*?value="([^"]+)', response).group(1)
        for src,subtitle in sources:
            # print(src,subtitle)
            ## https://fsharetv.com/api/file/9488a44bdc57483a7f8632a0f1fe67095OIPDeA0dak96DBWy6fRVg==/source?trailer=TSvm1vCSWb0
            respon = req.get(f'{domain}/api/file/{src}/source?trailer={ID}')
            r = json.loads(respon)
            SV = 0
            for i in r['data']['file']['alternatives']:
                server_name = f'SERVER {SV}'
                if server_name not in movie['group']: movie['group'][server_name] = []
                # print(r['data']['file']['alternatives'][SV])
                movie['group'][server_name].append({
                    'link': '',
                    'title': ''
                })
                SV += 1

            # if subviet is not None:
            #     sub = f'{domain}{subviet}'
            # else:
            #     sub = f'{domain}{subtitle}'
            # link = f'{domain}/api/file/{src}/source?trailer={ID}'
            # server_name = 'SERVER FSHARETV'
            # if server_name not in movie['group']: movie['group'][server_name] = []
            # movie['group'][server_name].append({
            #     'link': link,
            #     'sub': sub,
            #     'title': 'FULL'
            # })


        # get all server list
        # servers = soup.select("div#servers > div.server")
        # for server in servers:
        #     server_name = py2_encode(server.select_one('div.label').text.strip())

        #     if not re.search('[SRBH].PRO:', server_name): continue
        #     if server_name not in movie['group']: movie['group'][server_name] = []
        #     for ep in server.select('ul.episodelist li a'):
        #         movie['group'][server_name].append({
        #             'link': py2_encode(ep.get('href')),
        #             'title': py2_encode(ep.get('title'))
        #         })
        # print(movie)
        return movie

    def get_link(self, response, originURL):
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        # sources = re.search("var sources = (\[{.*}\]);", response) \
        #           or re.search("var sources[\s]?=[\s]?(\[{.*}\]);var", response)

        # if sources is not None:
        #     print(12313)
        #     return movie
        #     sources = json.loads(sources.group(1))
        #     for source in sources:
        #         url = unquote(re.search('\?url=(.*)', source['file']).group(1))
        #         movie['links'].append({
        #             'link': url,
        #             'title': 'Link %s' % py2_encode(source['label']),
        #             'type': py2_encode(source['label']),
        #             'originUrl': originURL,
        #             'resolve': False
        #         })


        # m = re.search('<iframe.*src="(.*?)"', response)
        # if m is not None:
        #     source = unquote(m.group(1)).replace('\\', '')
        #     if source:
        #         if 'embedss.php?link=' in source:
        #             source = re.search(r'embedss.php\?link=(.*)', source).group(1)

        #         movie['links'].append({
        #             'link': source,
        #             'title': py2_encode(source),
        #             'type': 'Unknow',
        #             'originUrl': originURL,
        #             'resolve': False
        #         })

        return movie

