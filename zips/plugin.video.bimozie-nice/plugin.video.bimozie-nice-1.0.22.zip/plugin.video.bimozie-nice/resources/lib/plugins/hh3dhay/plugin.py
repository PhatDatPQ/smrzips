from hh3dhay.parser.category import Parser as Category
from hh3dhay.parser.channel import Parser as Channel
from hh3dhay.parser.movie import Parser as Movie
from utils import csc_request as NICE
from utils import vddos as NIC3
from utils.mozie_request import Request

user_agent = (
    "Mozilla/5.0 (X11; Linux x86_64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/59.0.3071.115 Safari/537.36"
)

h = {
    'User-Agent': user_agent,
    # 'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    # 'Host': 'http://www.phimmoizz.net',
    # 'Referer': 'http://www.phimmoizz.net/vn.php'
}

class hh3dhay:
    domain = "https://hh3dhay.com"


    def __init__(self):
        NICEBYPASS = NICE.execute({'method': 'GET','url': self.domain,'timeout': 10,})
        self.VDDOS = NIC3.decrypt(NICEBYPASS.text)
        self.H = {'Accept-Language': 'vi-VN,vi;q=0.9','Cookie': f'vDDoS-so={self.VDDOS}'}

    def getCategory(self):
        response = NICE.execute({'method': 'GET','url': self.domain,'headers': self.H,'timeout': 10,})
        RT = response.content.decode('utf-8')
        return Category().get(RT), Channel().getTop(RT)

    def getChannel(self, channel, page=1):
        if page > 1:
            url = f'{channel}/page/{page}'
        else:
            url = channel
        response = NICE.execute({'method': 'GET','url': url,'headers': self.H,'timeout': 10,})
        return Channel().get(response.content.decode('utf-8'), page)

    def getMovie(self, id):
        url = '%s' % (id)
        response = NICE.execute({'method': 'GET','url': url,'headers': self.H,'timeout': 10,})
        url = Movie().get_movie_link(response.content.decode('utf-8'))
        response = NICE.execute({'method': 'GET','url': url,'headers': self.H,'timeout': 10,})
        return Movie().get(response.content.decode('utf-8'))

    def getLink(self, movie):
        url = '%s' % (movie['link'])
        response = NICE.execute({'method': 'GET','url': url,'headers': self.H,'timeout': 10,})
        return Movie().get_link(response.content.decode('utf-8'), self.domain, url, self.VDDOS)

    def search(self, text):
        url = "%s/search/%s" % (self.domain, text)
        response = NICE.execute({'method': 'GET','url': url,'headers': self.H,'timeout': 10,})
        return Channel().search_result(response.content.decode('utf-8'))
