# -*- coding: latin1 -*-
import re

from bs4 import BeautifulSoup
from utils.link_extractor import LinkExtractor
from utils.mozie_request import Request
from utils.xbmc_helper import text_encode
from kodi_six.utils import py2_encode
import utils.xbmc_helper as helper


class Parser:
    def get(self, response, referrer_url, skipEps=False):
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        soup = BeautifulSoup(response, "html.parser")
        # get server group and link
        servers = soup.select('div.player-warp')
        for server in servers:
            server_name = 'PHIMNHUA'
            if server_name not in movie['group']: movie['group'][server_name] = []
            # server_title = text_encode(server.select_one('h3.server-name').text.strip())
            # if server_title not in movie['group']: movie['group'][server_title] = []
            # self.get_server_eps(server, movie['group'][server_title])
            for ep in server.select('source'):
                movie['group'][server_name].append({
                    'link': py2_encode(ep.get('src')),
                    'title': 'FULL'
                })
                # movie['links'].append({
                #     'link': ep.get('src'),
                #     'title': 'Link HD',
                #     'type': 'stream',
                #     'resolve': False,
                #     'originUrl': referrer_url
                # })
        return movie

    @staticmethod
    def get_server_eps(content, group_link):
        for movie in content.select('ul > li > a'):
            group_link.append({
                'link': movie.get('href'),
                'title': "%s" % text_encode(movie.text)
            })

    def get_link(self, response, domain, referrer_url, request):
        helper.log("***********************Get Movie Link*****************************")
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        movie['links'].append({
            'link': referrer_url,
            'title': 'Link HD',
            'type': 'stream',
            'resolve': False,
            'originUrl': referrer_url
        })
        return movie
