# coding=utf-8
import re
import json
from bs4 import BeautifulSoup
from utils.mozie_request import AsyncRequest
from kodi_six.utils import py2_encode
from utils import csc_request as NICE


def from_char_code(*args):
    return ''.join(map(chr, args))

class Parser:
    def get_movie_link(self, response):
        soup = BeautifulSoup(response, "html.parser")
        return soup.findAll('a', {'class': 'btn btn-sm btn-danger watch-movie visible-xs-blockx'})[0].get('href')

    def get(self, response, skipEps=False):
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        soup = BeautifulSoup(response, "html.parser")
        servers = soup.select("div.halim-server.show_all_eps")
        for server in servers:
            server_name = py2_encode(server.select_one('span.halim-server-name').getText().strip())
            if server_name not in movie['group']: movie['group'][server_name] = []
            for ep in server.select('ul.halim-list-eps > li'):
                if ep.select_one('a') is not None:
                    ep = ep.select_one('a')
                    link = ep.get('href')
                else:
                    ep = ep.select_one('span')
                    link = ep.get('data-href')
                movie['group'][server_name].append({
                    'link': py2_encode(link),
                    'title': 'Tập %s' % py2_encode(ep.text.strip()),
                })
        return movie

    def get_link(self, response, domain, movie_url, VDDOS):
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        h = {
            'Accept': 'text/html, */*; q=0.01',
            'X-Requested-With': 'XMLHttpRequest',
            'Cookie': f'vDDoS-lJ={VDDOS}',
            'Referer' : movie_url
        }
        soup = BeautifulSoup(response, "html.parser")
        div = soup.find("div", class_="clearfix wrap-content")
        scr = str(div.find("script"))
        data = json.loads(re.findall(r'halim_cfg[^{]+(.*)</script>', str(scr), flags=re.DOTALL)[0])
        EPI = data['episode_slug']
        PID = data['post_id']
        SVID = data['server']
        # print(EPI,PID,SVID)
        listsv = ['']
        group_links = []
        servers = soup.select("div#halim-ajax-list-server > span")
        for i in servers:
            listsv.append(i.get('data-subsv-id'))
        for i in listsv:
            URL = f"{domain}/wp-content/themes/halimmovies/player.php?episode_slug={EPI}&server_id={SVID}&subsv_id={i}&post_id={PID}&nonce=&custom_var="
            CC = NICE.execute({'method': 'GET','url': URL,'headers': h,'timeout': 10,})
            group_links.append(Parser.extract_link(CC.content.decode('utf-8')))
        for links in group_links:
            for link in links:
                movie['links'].append({
                    'link': link[0],
                    'title': 'Link %s' % link[1],
                    'type': link[1],
                    'originUrl': movie_url,
                    'resolve': False
                })
        return movie
    @staticmethod
    def extract_link(response, args=None):
        links = []
        jData = json.loads(response)
        source = re.search(r"<iframe.*src=\"(.*?)\"", jData['data']['sources'])
        ytb = re.search(r"youtube", response)
        if ytb:
            source = (source.group(1), 'YTB')
        else:
            source = (source.group(1), 'NICE')
        links.append(source)
        return links
