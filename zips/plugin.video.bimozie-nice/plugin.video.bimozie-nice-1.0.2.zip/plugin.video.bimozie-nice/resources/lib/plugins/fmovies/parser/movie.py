# -*- coding: latin1 -*-
import re,sys

import utils.xbmc_helper as helper
from bs4 import BeautifulSoup
from utils.mozie_request import Request
import utils.fmoviesto as FMT
from utils.fmoviesto import FMTHelper
from kodi_six.utils import py2_encode

class Parser:
    def get(self, response, referrer_url, skipEps=False):
        req = Request()
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        recap="03AGdBq25eDJkrezDo2y"
        m_id = re.search(r'id="watch" data-id="(.*?)"', response).group(1)
        verid = FMTHelper.getVerid(m_id)
        respon = req.get('https://fmovies.to/ajax/film/servers', params={
            'id': m_id,
            'vrf': verid,
            'token': recap
        })
        respon = respon.replace('\\"','"').replace('\\n','')
        linki = re.findall('data-id="([^"]+).*?<div>([^<]+)',respon)
        for linkid1,host in linki:
            if host not in movie['group']: movie['group'][host] = []
            linkid = re.findall(linkid1+'"\:"([^"]+)',respon)#[0]
            if linkid:
                # print(linkid[0], host)
                movie['group'][host].append({
                    'link': py2_encode(linkid[0]),
                    'title': 'Full',
                })
        print(movie)
        return movie

    def get_link(self, response, domain, referrer_url, request):
        helper.log("***********************Get Movie Link*****************************")
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }

        # get server list
        soup = BeautifulSoup(response, "html.parser")

        return movie
    