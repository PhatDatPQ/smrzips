# -*- coding: utf-8 -*-
from bs4 import BeautifulSoup
import re
from kodi_six.utils import py2_encode
import utils.xbmc_helper as helper


class Parser:
    def get(self, response, page, domain):

        channel = {
            'page': page,
            'page_patten': None,
            'movies': []
        }

        soup = BeautifulSoup(response, "html.parser")
        # get total page
        last_page = soup.select('ul.pagination-list > li > a.page-link')
        helper.log("*********************** Get pages ")
        if len(last_page) > 1:
            channel['page'] = int(last_page[-2].text.strip())

        for movie in soup.select('div.myui-vodlist__box'):
            titles = movie.select_one('a.myui-vodlist__thumb')
            title = titles.get('title').strip()
            realtitle = movie.select_one('h4.title.text-overflow').text.strip()
            thumb = re.search(r"url\((.*)\);", titles.get('style'))
            type = movie.select_one('span.pic-tag').text.strip()      
            label = "[%s] %s" % (type, title)
            intro = ""
            channel['movies'].append({
                'id': titles.get('href'),
                'label': py2_encode(label),
                'title': py2_encode(title),
                'realtitle': py2_encode(realtitle),
                'thumb': f'{domain}{thumb.group(1)}',
                'type': py2_encode(type),
                'intro': py2_encode(intro),
            })
        return channel

    def getTop(self, response, domain):

        channel = {
            'page': 1,
            'page_patten': None,
            'movies': []
        }

        soup = BeautifulSoup(response, "html.parser")
        # print(soup)
        for movie in soup.select('ul.myui-vodlist.clearfix > li > div.myui-vodlist__box > a'):
            # tag = movie.select_one('a')
            title = movie.get('title').strip()
            realtitle = type = ""
            if movie.select_one('span.pic-tag') is not None:
                type = movie.select_one('span.pic-tag').text.strip()
            if movie.select_one('h4.title.text-overflow') is not None:
                realtitle = movie.select_one('h4.title.text-overflow').text.strip()
            # if realtitle is not None:
            #     label = "[%s] %s - %s" % (type, title, realtitle)
            # else:
            label = "[%s] %s" % (type, title)
            thumb = re.search(r"url\((.*)\);", movie.get('style'))
            channel['movies'].append({
                'id': py2_encode(movie.get('href')),
                'label': py2_encode(label),
                'intro': py2_encode(label),
                'title': py2_encode(title),
                'realtitle': py2_encode(realtitle),
                'thumb': f'{domain}{thumb.group(1)}',
                'type': py2_encode(type),
            })
        return channel

    def search_result(self, response, domain):
        channel = {
            'page': 1,
            'page_patten': None,
            'movies': []
        }
        try:
            soup = BeautifulSoup(response, "html.parser")
            for movie in soup.select('div.myui-vodlist__box'):
                titles = movie.select_one('a.myui-vodlist__thumb')
                title = titles.get('title').strip()
                realtitle = movie.select_one('h4.title.text-overflow').text.strip()
                thumb = re.search(r"url\((.*)\);", titles.get('style'))
                type = movie.select_one('span.pic-tag').text.strip()      
                label = "[%s] %s" % (type, title)
                intro = ""
                channel['movies'].append({
                    'id': titles.get('href'),
                    'label': py2_encode(label),
                    'title': py2_encode(title),
                    'realtitle': py2_encode(realtitle),
                    'thumb': f'{domain}{thumb.group(1)}',
                    'type': py2_encode(type),
                    'intro': py2_encode(intro),
                })
        except: pass
        return channel
