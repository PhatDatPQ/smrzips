#!/usr/bin/env python
# -*- coding: utf-8 -*-
import js2py
import base64
import re
import ast
from min import *

def decrypt(response):
    toNumbers = js2py.eval_js("function toNumbers(d){var e=[];d.replace(/(..)/g,function(d){e.push(parseInt(d,16))});return e}")
    toHex = js2py.eval_js('function toHex(){for(var d=[],d=1==arguments.length&&arguments[0].constructor==Array?arguments[0]:arguments,e="",f=0;f<d.length;f++)e+=(16>d[f]?"0":"")+d[f].toString(16);return e.toLowerCase()}')
    try:
        FuckVVDOS = re.findall('=(.*?)\;.*?atob\("(.*?)"\).*?toNumbers\("(.*?)"\).*?document.cookie=\"(.*?)"',response ,re.DOTALL)
        if len(FuckVVDOS[0]) > 1:
            LISTA2G = ast.literal_eval(FuckVVDOS[0][0])
            a2G = LISTA2G[7]
            b1G = FuckVVDOS[0][1]
            c3G = FuckVVDOS[0][2]
            vDdos = FuckVVDOS[0][3]
        else:
            a2GF = re.search(r'_0xf20d=(.*?)\;', response).group(1)
            LISTA2G = ast.literal_eval(a2GF)
            a2G = LISTA2G[7]
            b1G = re.search(r'atob\("(.*?)"\)', response).group(1)
            c3G = re.search(r'toNumbers\("(.*?)"\)', response).group(1)
            vDdos = re.search(r'document.cookie=\"(.*?)"', response).group(1)
        b1 = base64.b64decode(b1G).decode("utf-8")
        b2 = toNumbers(f"{b1}")
        a2 = base64.b64decode(a2G).decode("utf-8")
        a1 = toNumbers(f"{a2}")
        c3 = toNumbers(c3G)
        kq = vDdos + toHex(min.slowAES.decrypt(c3,2,a1,b2))
    except:
        try:
            FuckVVDOS = re.findall('toNumbers\("(.*?)"\).*?atob\("(.*?)"\).*?toNumbers\("(.*?)"\).*?document.cookie=\"(.*?)"',response ,re.DOTALL)
            a1G = FuckVVDOS[0][0]
            b1G = FuckVVDOS[0][1]
            c3G = FuckVVDOS[0][2]
            vDdos = FuckVVDOS[0][3]
            b1 = base64.b64decode(b1G).decode("utf-8")
            b2 = toNumbers(f"{b1}")
            a1 = toNumbers(f"{a1G}")
            c3 = toNumbers(c3G)
            kq = vDdos + toHex(min.slowAES.decrypt(c3,2,a1,b2))            
        except:
            try:
                FuckVVDOS = re.findall('atob\("(.*?)"\).*?=\["(.*?)"\].*?=.*?toNumbers\("(.*?)"\).*?document.cookie=\"(.*?)"',response ,re.DOTALL)
                b1G= FuckVVDOS[0][0]
                a1G  = FuckVVDOS[0][1]
                c3G = FuckVVDOS[0][2]
                vDdos = FuckVVDOS[0][3]
                ETH = (bytes.fromhex(a1G.replace("\\x", ""))).decode('utf-8')
                ETH = base64.b64decode(ETH).decode("utf-8")
                b1 = base64.b64decode(b1G).decode("utf-8")
                a1 = toNumbers(f"{ETH}")
                b2 = toNumbers(f"{b1}")
                c3 = toNumbers(c3G)
                kq = vDdos + toHex(min.slowAES.decrypt(c3,2,a1,b2))
            except:
                FuckVVDOS = re.findall('var.*?=(.*?)\;.*?atob\("(.*?)"\).*?toNumbers\("(.*?)"\).*?document.cookie=\"(.*?)"',response ,re.DOTALL)
                b1G= FuckVVDOS[0][0]
                a1G  = FuckVVDOS[0][1]
                c3G = FuckVVDOS[0][2]
                vDdos = FuckVVDOS[0][3]
                LISTA2G = ast.literal_eval(FuckVVDOS[0][0])
                # a2G = LISTA2G[7]
                a2G = base64.b64decode(LISTA2G[7]).decode("utf-8")
                c2G = base64.b64decode(a1G).decode("utf-8")
                c2 = toNumbers(f"{c2G}")
                a1 = toNumbers(c3G)
                b1 = toNumbers(f"{a2G}")
                kq = vDdos + toHex(min.slowAES.decrypt(a1,2,b1,c2))
    return kq

