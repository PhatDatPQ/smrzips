from bilutv.parser.category import Parser as Category
from bilutv.parser.channel import Parser as Channel
from bilutv.parser.movie import Parser as Movie
from six.moves.urllib.parse import quote_plus
from utils import csc_request as NICE

class Bilutv:
    ## https://bilutv.link/
    domain = "https://bylutv.com"

    def getCategory(self):
        response = NICE.execute({'cfscrape': True,'method': 'GET','url': self.domain,'timeout': 10,})
        return Category().get(response.text), Channel().get(response.text)

    def getChannel(self, channel, page=1):
        channel = channel.replace(self.domain, "")
        if page > 1:
            channel = channel.replace('.html/', "/")
            channel = channel.replace('.html', "/")
            url = '%s%strang-%d' % (self.domain, channel, page)
        else:
            url = '%s%s' % (self.domain, channel)
        response = NICE.execute({'method': 'GET','url': url,'timeout': 10,})
        return Channel().get(response.text)

    def getMovie(self, mid):
        response = NICE.execute({'method': 'GET','url': mid,'timeout': 10,})
        url = Movie().get_movie_link(response.text)
        response = NICE.execute({'method': 'GET','url': url,'timeout': 10,})
        return Movie().get(response.text)

    def getLink(self, movie):
        response = NICE.execute({'method': 'GET','url': movie['link'],'timeout': 10,})
        return Movie().get_link(response.text, self.domain)

    def search(self, text, page=1):
        url = "%s/tim-kiem/?q=%s" % (self.domain, quote_plus(text))
        response = NICE.execute({'method': 'GET','url': url,'timeout': 10,})
        return Channel().get(response.text)
