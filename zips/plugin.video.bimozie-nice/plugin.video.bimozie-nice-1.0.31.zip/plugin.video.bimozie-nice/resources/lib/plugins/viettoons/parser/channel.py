# -*- coding: utf-8 -*-
from bs4 import BeautifulSoup
import re
from kodi_six.utils import py2_encode
import utils.xbmc_helper as helper


class Parser:
    def get(self, response, page, domain):

        channel = {
            'page': page,
            'page_patten': None,
            'movies': []
        }
        soup = BeautifulSoup(response, "html.parser")
        last_page = soup.select_one('a.page__next')
        catalog_page = soup.select('ul.catalog__paginator > li > a')
        helper.log("*********************** Get pages ")
        if last_page is not None:
            if len(last_page) >= 1:
                p = last_page.get('href')
                channel['page'] = int(re.findall("\d+", p)[0])
        else:
            if catalog_page is not None:
                if len(catalog_page) > 1:
                    c = catalog_page[-1].get('href')
                    try:
                        channel['page'] = int(re.findall("\d+", c)[0])
                    except:
                        channel['page'] = int(catalog_page[-1].text.strip())

        for movie in soup.select('div.card'):
            tag = movie.select_one('a')
            img = movie.select_one('a > img')
            title = movie.select_one('h3 > a').text.strip()
            realtitle = type = ""
            if movie.select_one('div > span') is not None:
                type = movie.select_one('div > span').text.strip()
            label = "[%s] %s" % (type, title)
            thumb = img.get('data-src')
            channel['movies'].append({
                'id': py2_encode(tag.get('href')),
                'label': py2_encode(label),
                'intro': py2_encode(label),
                'title': py2_encode(title),
                'realtitle': py2_encode(realtitle),
                'thumb': f'{domain + thumb}',
                'type': py2_encode(type),
            })
        return channel

    def getTop(self, response, domain):
        channel = {
            'page': 1,
            'page_patten': None,
            'movies': []
        }
        soup = BeautifulSoup(response, "html.parser")
        for movie in soup.select('div.card'):
            tag = movie.select_one('a')
            img = movie.select_one('a > img')
            title = movie.select_one('h3 > a').text.strip()
            realtitle = type = ""
            if movie.select_one('div > span') is not None:
                type = movie.select_one('div > span').text.strip()
            label = "[%s] %s" % (type, title)
            thumb = img.get('data-src')
            channel['movies'].append({
                'id': py2_encode(tag.get('href')),
                'label': py2_encode(label),
                'intro': py2_encode(label),
                'title': py2_encode(title),
                'realtitle': py2_encode(realtitle),
                'thumb': f'{domain + thumb}',
                'type': py2_encode(type),
            })
        return channel

    def search_result(self, response, domain):
        channel = {
            'page': 1,
            'page_patten': None,
            'movies': []
        }
        try:
            soup = BeautifulSoup(response, "html.parser")
            for movie in soup.select('div.card'):
                tag = movie.select_one('a')
                img = movie.select_one('a > img')
                title = movie.select_one('h3 > a').text.strip()
                realtitle = type = ""
                if movie.select_one('div > span') is not None:
                    type = movie.select_one('div > span').text.strip()
                label = "[%s] %s" % (type, title)
                thumb = img.get('data-src')
                channel['movies'].append({
                    'id': py2_encode(tag.get('href')),
                    'label': py2_encode(label),
                    'intro': py2_encode(label),
                    'title': py2_encode(title),
                    'realtitle': py2_encode(realtitle),
                    'thumb': f'{domain + thumb}',
                    'type': py2_encode(type),
                })
        except: pass
        return channel
