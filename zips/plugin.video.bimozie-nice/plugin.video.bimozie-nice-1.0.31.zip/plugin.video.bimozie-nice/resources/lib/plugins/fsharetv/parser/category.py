#!/usr/bin/env python
# coding=utf-8
from bs4 import BeautifulSoup
from kodi_six.utils import py2_encode


class Parser:
    def get(self, response):
        category = []
        soup = BeautifulSoup(response, "html.parser")

        for item in soup.select('div.swiper-slide.menu > div.accordion')[0:-5]:
            menu = item.select_one('label.accordion-header')
            try:
                link = menu.select_one('a').get("href")
            except:
                link = '#'
            category.append({
                'title': py2_encode((menu.text).replace('\n','').upper()),
                'link': link,
                'subcategory': self.getsubmenu(item)
            })
        return category

    def getsubmenu(self, xpath):
        category = []
        if xpath.select('ul > li'):
            for item in xpath.select('a'):
                category.append({
                    'title': py2_encode(item.text),
                    'link': item.get('href')
                })

        return category

