# -*- coding: utf-8 -*-
import json
import re

from bs4 import BeautifulSoup
from kodi_six.utils import py2_encode
from six.moves.urllib.parse import unquote
from utils.xbmc_helper import text_encode
from utils.wisepacker import WisePacker
import utils.xbmc_helper as helper



def from_char_code(*args):
    return ''.join(map(chr, args))


class Parser:
    key = "PhimMoi.Net@"

    def get_movie_link(self, response):
        soup = BeautifulSoup(response, "html.parser")
        return soup.select_one('a.btn-watch').get('href')

    def get(self, response,request,cookie, skipEps=False):
        # print(response)
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        soup = BeautifulSoup(response, "html.parser")
        # get all server list
        servers = soup.select("div.serverlist > div.server")
        for server in servers:
            for sv in server.select('ul.episodelistsv li a'):
                server_name = sv.text.strip()
                listsv = sv.get('href')
                if server_name not in movie['group']: movie['group'][server_name] = []
                r1 = request.get(listsv, cookies=cookie)
                s1 = BeautifulSoup(r1, "html.parser")
                listep = s1.select("div#servers > div.server")
                for serverlistep in listep:
                    for ep in serverlistep.select('ul.episodelist li a'):
                        movie['group'][server_name].append({
                            'link': py2_encode(ep.get('href')),
                            'title': py2_encode((ep.get('title')).upper())
                        })
        return movie

    def get_link(self, response, originURL):
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        sources = re.search("var sources = (\[{.*}\]);", response) \
                  or re.search("var sources[\s]?=[\s]?(\[{.*}\]);var", response)
        if sources is not None:
            print(12313)
            return movie
            sources = json.loads(sources.group(1))
            for source in sources:
                url = unquote(re.search('\?url=(.*)', source['file']).group(1))
                movie['links'].append({
                    'link': url,
                    'title': 'Link %s' % py2_encode(source['label']),
                    'type': py2_encode(source['label']),
                    'originUrl': originURL,
                    'resolve': False
                })
        m = re.search('<iframe.*src="(.*?)"', response)
        if m is not None:
            source = unquote(m.group(1)).replace('\\', '')
            if source:
                if 'embedss.php?link=' in source:
                    source = re.search(r'embedss.php\?link=(.*)', source).group(1)
                if 'embedsp.php?link=' in source:
                    source = re.search(r'embedsp.php\?link=(.*)', source).group(1)

                movie['links'].append({
                    'link': source,
                    'title': py2_encode(source),
                    'type': 'Unknow',
                    'originUrl': originURL,
                    'resolve': False
                })
        nice = self.get_decrypt_key(response)
        if nice is not None:
            movie['links'].append({
                    'link': nice,
                    'title': py2_encode(nice),
                    'type': 'Unknow',
                    'originUrl': originURL,
                    'resolve': False
                })
        return movie
    def get_decrypt_key(self, response):
        try:
            a = WisePacker.decode(response)
            return re.search(r'embedsp.php\?link=(.*)"', a).group(1)
        except:
            helper.message("LH CHỦ THỚT ĐỂ BÁO LỖI", "TVHAY", 15000)


