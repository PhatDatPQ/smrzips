from six.moves.urllib.parse import quote_plus
from fsharetv.parser.category import Parser as Category
from fsharetv.parser.channel import Parser as Channel
from fsharetv.parser.movie import Parser as Movie
from utils.mozie_request import Request


class fsharetv:
    domain = "https://fsharetv.com"
    cookie = {}
    h = {
        'Referer': domain,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/73.0.3683.86 Safari/537.36'
    }

    def __init__(self):
        self.request = Request(self.h, session=True)
    def getCategory(self):
        response = self.request.get(self.domain, cookies=self.cookie)
        return Category().get(response), Channel().get(response, 1)

    def getChannel(self, channel, page=1):
        channel = channel.replace("https://fsharetv.com", "")
        channel = channel.replace(self.domain, "")
        if page > 1:
            if 'year' in channel:
                schanel = channel.split('?')
                url = '%s%s?page=%d&%s' % (self.domain, schanel[0], page, schanel[1])
            else:
                url = '%s%s?page=%d' % (self.domain, channel, page)
        else:
            url = '%s%s' % (self.domain, channel)
        response = self.request.get(url, cookies=self.cookie)
        return Channel().get(response, page)

    def getMovie(self, id):
        response = self.request.get(f'{self.domain}{id}', cookies=self.cookie)
        return Movie().get(response,self.domain)

    def getLink(self, movie):
        response = self.request.get(movie['link'], cookies=self.cookie)
        return Movie().get_link(response, movie['link'])

    def search(self, text):
        url = "%s/search/%s" % (self.domain, quote_plus(text))
        response = self.request.get(url, cookies=self.cookie)
        return Channel().get(response, 1)
