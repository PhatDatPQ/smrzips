# -*- coding: utf-8 -*-
import json
import re
from . import xbmc_helper as helper


class LinkExtractor:
    def __init__(self):
        pass

    @staticmethod
    def findall(pattern, string):
        while True:
            match = re.search(pattern, string)
            if not match:
                break
            yield match.group(1)
            string = string[match.end():]

    @staticmethod
    def iframe(txt, all=False):
        pattern = r'''<iframe(?:(?!<iframe).*?src=['|"](.*?)['|"])'''
        if all:
            return re.findall(pattern, txt)
        else:
            reg = re.search(pattern, txt)
            if reg:
                helper.log("Found iframe source: {}".format(reg.group(1)))
                return reg.group(1)

        return None

    @staticmethod
    def play_sources(txt):
        reg = re.search(r'sources:\s?(\[.*?\])', txt, re.DOTALL)
        if reg:
            helper.log("Found iframe source: {}".format(reg.group(1)))
            return helper.convert_js_2_json(reg.group(1))
        return None
    @staticmethod
    def play_sources_viupload(txt):
        reg = list(LinkExtractor.findall(r'sources:\s?(\[.*?\])', txt))
        if reg:
            for item in reg:
                if len(item) > 100:
                    return helper.convert_js_2_json(item)
        return None
