#!/usr/bin/env python
# -*- coding: utf-8 -*-
import re

from bs4 import BeautifulSoup
from kodi_six.utils import py2_encode
import utils.xbmc_helper as helper
from urllib.parse import unquote


class Parser:
    def get(self, response, page):

        channel = {
            'page': page,
            'page_patten': None,
            'movies': []
        }

        soup = BeautifulSoup(response, "html.parser")
        # get total page
        last_page = soup.select('div.text-center.mb-2 > a')
        if last_page is not None:
            page = last_page[-1].text.strip()
            channel['page'] = int(page)

        movies = soup.select('div > div.columns > div.column.movie-item')
        if len(movies) > 0:
            for movie in movies:
                title = movie.select_one('b').text
                type = ""
                realtitle = ""
                if movie.select('span') is not None:
                    realtitle = movie.select('span')[-1].text.strip()
                    type = movie.select('span')[0].text.strip()
                    tym = movie.select('span')[1].text.strip()   
                if realtitle is not None:
                    if len(realtitle) > 1:
                        label = "[%s] %s - %s" % (type, title, realtitle)
                    else:
                        label = "[%s] %s" % (type, title)  
                else:
                    label = "[%s] %s" % (type, title)                
                thumb = movie.select_one('a img').get('src')
                try:
                    thumb = unquote((re.search(r'url=(.*)&', thumb).group(1)).replace('_V1_SX300',''))
                except:pass
                channel['movies'].append({
                    'id': movie.select_one('a').get('href'),
                    'label': py2_encode(label),
                    'intro': py2_encode(f'{tym} ♥ {label}'),
                    'title': py2_encode(title),
                    'realtitle': py2_encode(realtitle),
                    'thumb': thumb,
                    'type': py2_encode(type),
                })
        return channel
