from bilutv.parser.category import Parser as Category
from bilutv.parser.channel import Parser as Channel
from bilutv.parser.movie import Parser as Movie
from six.moves.urllib.parse import quote_plus
from utils.mozie_request import Request

user_agent = (
    "Mozilla/5.0 (X11; Linux x86_64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/59.0.3071.115 Safari/537.36"
)

h = {
    'User-Agent': user_agent,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    # 'Host': 'http://www.phimmoizz.net',
    # 'Referer': 'http://www.phimmoizz.net/vn.php'
}


class Bilutv:
    ## https://bilutv.link/
    domain = "https://bylutv.com"
    def __init__(self):
        self.request = Request(h, session=True)
    def getCategory(self):
        # url = "%s/%s" % (self.domain, 'danh-sach/')
        # # url = "%s" % (self.domain)
        # response = Request().get(self.domain)
        response = self.request.get('{}/'.format(self.domain), headers=h)
        print(response)
        return Category().get(response), Channel().get(response)

    def getChannel(self, channel, page=1):
        channel = channel.replace(self.domain, "")
        if page > 1:
            channel = channel.replace('.html/', "/")
            channel = channel.replace('.html', "/")
            url = '%s%s/trang-%d' % (self.domain, channel, page)
        else:
            url = '%s%s' % (self.domain, channel)

        response = Request().get(url)
        return Channel().get(response)

    def getMovie(self, mid):
        # url = "%s/phim/%s-0000.html" % (self.domain, id)
        response = Request().get(mid)
        url = Movie().get_movie_link(response)
        response = Request().get(url)
        return Movie().get(response)

    def getLink(self, movie):
        response = Request().get(movie['link'])
        return Movie().get_link(response, self.domain)

    def search(self, text, page=1):
        url = "%s/tim-kiem/%s.html" % (self.domain, quote_plus(text))
        response = Request().get(url)
        return Channel().get(response)
