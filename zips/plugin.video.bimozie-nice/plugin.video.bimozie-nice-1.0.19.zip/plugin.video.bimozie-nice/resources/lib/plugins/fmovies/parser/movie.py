# -*- coding: utf-8 -*-
import re,sys
import utils.xbmc_helper as helper
from bs4 import BeautifulSoup
from utils.mozie_request import Request
import utils.fmoviesto as FMT
from utils.fmoviesto import FMTHelper
from kodi_six.utils import py2_encode
from six.moves.urllib.parse import unquote

class Parser:
    def get(self, response, referrer_url, skipEps=False):
        req = Request()
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        recap="03AGdBq25eDJkrezDo2y"
        m_id = re.search(r'id="watch" data-id="(.*?)"', response).group(1)
        titlec = re.search(r'alt="(.*?)"', response).group(1)
        print(m_id)
        print(titlec)

        verid = FMTHelper.getVerid(m_id)
        respon = req.get('https://fmovies.to/ajax/film/servers', params={
            'id': m_id,
            'vrf': verid,
            # 'token': recap
        })
        print(respon)
        
        respon = respon.replace('\\"','"').replace('\\n','')
        soup = BeautifulSoup(respon, "html.parser")
        linki2 = re.findall('value="([^"]+).*?<label.*?>([^<]+).*?<span.*?>([^<]+)',respon)
        for linkid1,ss,ss2 in linki2:
            if ss not in movie['group']: movie['group'][ss] = []
            for ep in soup.find_all("div", {"class": "episodes", "data-season": f"{linkid1}"}):
                for item in ep.select('div.episode > a'):
                    try:
                        phan,tap = item.get("data-kname").split('-')
                    except:
                        phan,tap,lol = item.get("data-kname").split('-')
                    label = item.get("title")
                    if label == ' - ':
                        title = f'[{tap.upper()}] - {titlec}'
                    else:
                        title = f'[SS {phan} - Tập {tap.upper()}] {item.get("title")}'
                    movie['group'][ss].append({
                    'link': py2_encode(item.get("href")),
                    'title': title,
                    'data-ep': item.get("data-ep"),
                    })
        return movie

    def get_link(self, listsv, domain, referrer_url, request):
        import json
        # import xbmcgui
        helper.log("***********************Get Movie Link*****************************")
        movie = {
            'group': {},
            'episode': [],
            'links': [],
        }
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:85.0) Gecko/20100101 Firefox/85.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'pl,en-US;q=0.7,en;q=0.3',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'TE': 'Trailers',
        }
        headers.update({'Referer': referrer_url})
        sources = json.loads(listsv)
        links = []
        subt = False
        for i in sources:
            respon = request.get('https://fmovies.to/ajax/episode/info', headers=headers,params={
                'id': sources[i],
            })
            # get server list
            jsonab = json.loads(respon)
            link2 = FMTHelper.DecodeLink(jsonab['url'])
            reg = '?sub.info='
            reg = reg if reg in link2 else '?subtitle_json='
            link,subt = link2.split(reg)
            subtx = unquote(subt)
            links.append((link, 'NICE', subtx))            
        for link in links:
            movie['links'].append({
                'link': link[0],
                'title': 'Link %s' % link[1],
                'type': link[1],
                'resolve': False,
                'originUrl': referrer_url,
                'subtitlez' : link[2]
            })
        return movie
    