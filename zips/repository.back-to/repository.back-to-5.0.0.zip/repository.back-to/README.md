# back-to repository

- source https://github.com/back-to/repo
- Version: 5.0.0
- Download: [ZIP](https://github.com/back-to/repo/blob/master/repository.back-to/repository.back-to-5.0.0.zip?raw=true)

# support

- liveproxy: https://github.com/back-to/liveproxy/issues
- custom plugins: https://github.com/back-to/plugins/issues
- default plugins: https://github.com/streamlink/streamlink/issues
